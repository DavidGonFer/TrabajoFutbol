<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Jugador;
use Illuminate\Support\Facades\Redirect;

class JugadoresController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $jugadores = Jugador::all();
            return View('index',[
            'jugadores' => $jugadores
            ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $jugadores = new Jugador();
        return View('save',[
            'jugadores' => $jugadores
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $jugadores = new Jugador();
        $jugadores -> nombre = $request -> nombre;
        $jugadores -> cod_asi = $request -> cod_asi;
        $jugadores -> fecha_nacimiento = $request -> fecha_nacimiento;
        $jugadores -> apellidos = $request -> apellidos;
        $jugadores -> telefono = $request -> telefono;
        $jugadores -> observaciones = $request -> observaciones;
        $jugadores -> save();
        return Redirect::to('jugadores')->with('jugadores', 'Se ha creado el jugador correctamente');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $jugadores = Jugador::find($id);
            return View('show',[
            'jugadores' => $jugadores
            ]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $jugadores = Jugador::find($id);
        return View('save',[
            'jugadores' => $jugadores
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $jugadores = Jugador::find($id);
        $jugadores -> nombre = $request -> nombre;
        $jugadores -> fecha_nacimiento = $request -> fecha_nacimiento;
        $jugadores -> apellidos = $request -> apellidos;
        $jugadores -> telefono = $request -> telefono;
        $jugadores -> observaciones = $request -> observaciones;
        $jugadores -> save();
    }   

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $jugadores = Jugador::find($id);
        $jugadores -> delete();
        return Redirect::to('jugadores') -> with('jugadores', 'El jugador ha sido eliminado correctamente');
    }
}
