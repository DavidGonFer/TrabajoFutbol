<!DOCTYPE html>
<html>
    <header></header>
    <body>
        <h1>LISTA DE ENTRENAMIENTOS</h1>
        <?php $__currentLoopData = $entrenamientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entrenamiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action='<?php echo e(url("entrenamientos/$entrenamiento->id")); ?>' method="POST">
                <?php echo csrf_field(); ?>
                <?php echo e($entrenamiento['cod_asi']); ?> <br>
                <?php echo e($entrenamiento['fecha_hora']); ?> <br>
                <?php echo e($entrenamiento['duracion']); ?> <br>
                <?php echo e($entrenamiento['observaciones']); ?> <br>
                <input type="hidden" name="_method" value="DELETE">
                <input type="submit" value="Eliminar">
                <a href=<?php echo e(url("entrenamientos/$entrenamiento->id/edit")); ?>>Editar</a>
                <a href=<?php echo e(url("entrenamientos/$entrenamiento->id")); ?>>Ver</a>
                
            </form>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <p><a href=<?php echo e(url("entrenamientos/create")); ?>>Crear entrenamiento</a></p>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tabla_jugadores\resources\views/entrenamientos/index.blade.php ENDPATH**/ ?>