<!DOCTYPE html>
<html>
    <header>
        <title>Guardar</title>
        <h1>Guardar entrenamiento</h1>
    </header>
    <body>
        <form action='<?php echo e(url("entrenamientos/$entrenamientos->id")); ?>' method="POST">
            <?php echo csrf_field(); ?>
            <?php if($entrenamientos->id): ?>
                <input type="hidden" name="_method" value="PUT">
            <?php endif; ?>

            <br>Código asitencia:<input type="number" name="cod_asi" value="<?php echo e($entrenamientos->cod_asi); ?>">
            <br>Fecha y hora:<input type="text" name="fecha_hora" value="<?php echo e($entrenamientos->fecha_hora); ?>">
            <br>Duración:<input type="number" name="duracion" value="<?php echo e($entrenamientos->duracion); ?>">
            <br>Observaciones:<input type="text" name="observaciones" value="<?php echo e($entrenamientos->observaciones); ?>">
            <input type="submit" value="Guardar">
        </form>
        <p><a href = <?php echo e(url("entrenamientos")); ?>>Cancelar</a></p>
    </body>
</html><?php /**PATH C:\xampp\htdocs\tabla_jugadores\resources\views/entrenamientos/save.blade.php ENDPATH**/ ?>