<!DOCTYPE html>
<html>
    <header>
        <title>Ver jugadores</title>
    </header>
    <body>
        <h1>JUGADOR</h1>
        <?php if($jugadores!=null): ?>
            <p>ID: <?php echo e($jugadores->id); ?> </p>
            <p>NOMBRE: <?php echo e($jugadores->nombre); ?></p>
            <p>FECHA DE NACIMIENTO: <?php echo e($jugadores->fecha_nacimiento); ?></p>
            <p>APELLIDOS: <?php echo e($jugadores->apellidos); ?></p>
            <p>TELÉFONO: <?php echo e($jugadores->telefono); ?></p>
            <p>OBSERVACIONES: <?php echo e($jugadores->observaciones); ?></p>
        <?php else: ?>
            <p>NO EXISTE EL JUGADOR</p>
        <?php endif; ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\tabla_jugadores\resources\views/show.blade.php ENDPATH**/ ?>