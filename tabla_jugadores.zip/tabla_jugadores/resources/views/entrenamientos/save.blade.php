<!DOCTYPE html>
<html>
    <header>
        <title>Guardar</title>
        <h1>Guardar entrenamiento</h1>
    </header>
    <body>
        <form action='{{url("entrenamientos/$entrenamientos->id")}}' method="POST">
            @csrf
            @if($entrenamientos->id)
                <input type="hidden" name="_method" value="PUT">
            @endif

            <br>Código asitencia:<input type="number" name="cod_asi" value="{{$entrenamientos->cod_asi}}">
            <br>Fecha y hora:<input type="text" name="fecha_hora" value="{{$entrenamientos->fecha_hora}}">
            <br>Duración:<input type="number" name="duracion" value="{{$entrenamientos->duracion}}">
            <br>Observaciones:<input type="text" name="observaciones" value="{{$entrenamientos->observaciones}}">
            <input type="submit" value="Guardar">
        </form>
        <p><a href = {{url("entrenamientos")}}>Cancelar</a></p>
    </body>
</html>