<!DOCTYPE html>
<html>
    <header>
        <title>Ver entrenamientos</title>
    </header>
    <body>
        <h1>ENTRENAMIENTO</h1>
        @if ($entrenamiento!=null)
            <p>ID: {{$entrenamiento->id}} </p>
            <p>CÓDIGO DE ASISTENCIA: {{$entrenamiento->cod_asi}}</p>
            <p>FECHA Y HORA: {{$entrenamiento->fecha_hora}}</p>
            <p>DURACIÓN: {{$entrenamiento->duracion}}</p>
            <p>OBSERVACIONES: {{$entrenamiento->observaciones}}</p>
        @else
            <p>NO EXISTE EL ENTRENAMIENTO</p>
        @endif

    </body>
</html>
