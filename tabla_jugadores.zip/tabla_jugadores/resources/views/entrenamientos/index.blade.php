<!DOCTYPE html>
<html>
    <header></header>
    <body>
        <h1>LISTA DE ENTRENAMIENTOS</h1>
        @foreach($entrenamientos as $entrenamiento)
            <form action='{{url("entrenamientos/$entrenamiento->id")}}' method="POST">
                @csrf
                {{$entrenamiento['cod_asi']}} <br>
                {{$entrenamiento['fecha_hora']}} <br>
                {{$entrenamiento['duracion']}} <br>
                {{$entrenamiento['observaciones']}} <br>
                <input type="hidden" name="_method" value="DELETE">
                <input type="submit" value="Eliminar">
                <a href={{url("entrenamientos/$entrenamiento->id/edit")}}>Editar</a>
                <a href={{url("entrenamientos/$entrenamiento->id")}}>Ver</a>
                
            </form>
        @endforeach

        <p><a href={{url("entrenamientos/create")}}>Crear entrenamiento</a></p>
    </body>
</html>
