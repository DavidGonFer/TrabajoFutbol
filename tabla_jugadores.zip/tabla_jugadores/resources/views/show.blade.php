<!DOCTYPE html>
<html>
    <header>
        <title>Ver jugadores</title>
    </header>
    <body>
        <h1>JUGADOR</h1>
        @if ($jugadores!=null)
            <p>ID: {{$jugadores->id}} </p>
            <p>NOMBRE: {{$jugadores->nombre}}</p>
            <p>FECHA DE NACIMIENTO: {{$jugadores->fecha_nacimiento}}</p>
            <p>APELLIDOS: {{$jugadores->apellidos}}</p>
            <p>TELÉFONO: {{$jugadores->telefono}}</p>
            <p>OBSERVACIONES: {{$jugadores->observaciones}}</p>
        @else
            <p>NO EXISTE EL JUGADOR</p>
        @endif

    </body>
</html>
