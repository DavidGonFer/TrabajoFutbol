<!DOCTYPE html>
<html>
    <header>
        <title>Guardar</title>
        <h1>Guardar jugador</h1>
    </header>
    <body>
        <form action='{{url("jugadores/$jugadores->id")}}' method="POST">
            @csrf
            @if($jugadores->id)
                <input type="hidden" name="_method" value="PUT">
            @endif

            <br>Código asitencia:<input type="number" name="cod_asi" value="{{$jugadores->cod_asi}}">
            <br>Nombre:<input type="text" name="nombre" value="{{$jugadores->nombre}}">
            <br>Fecha de nacimiento:<input type="text" name="fecha_nacimiento" value="{{$jugadores->fecha_nacimiento}}">
            <br>Apellidos:<input type="text" name="apellidos" value="{{$jugadores->apellidos}}">
            <br>Teléfono:<input type="text" name="telefono" value="{{$jugadores->telefono}}">
            <br>Observaciones:<input type="text" name="observaciones" value="{{$jugadores->observaciones}}">
            <input type="submit" value="Guardar">
        </form>
        <p><a href = {{url("jugadores")}}>Cancelar</a></p>
    </body>
</html>